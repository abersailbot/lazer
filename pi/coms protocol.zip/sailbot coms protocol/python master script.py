import serial
 
ser = serial.Serial()
ser.baudrate = 115200
ser.port = 'COM7'
ser.open()
 
values = [1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7,8,9]
ser.write(values)
 
 
while True:
    raw_out=ser.read()
    print(chr(raw_out[0]))

    
